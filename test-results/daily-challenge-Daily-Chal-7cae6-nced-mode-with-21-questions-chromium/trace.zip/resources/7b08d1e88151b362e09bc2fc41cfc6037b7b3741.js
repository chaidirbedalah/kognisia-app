(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_61617bf2._.js",
  "static/chunks/src_44d2a88d._.js"
],
    source: "dynamic"
});
